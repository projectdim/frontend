import LoginModal from "./LoginModal.vue";
import modalTemplate from "./ModalTemplate.vue";
import ConfirmModal from "./ConfirmModal.vue";


export default [
  LoginModal,
  modalTemplate,
  ConfirmModal
]
