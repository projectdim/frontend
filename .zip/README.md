## Project installation


Install node modules with :
```
npm install
```

Run dev server with :
```
npm run dev
```

Build dist package with :
```
npm run build
```