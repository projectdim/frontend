import Button_1 from "./Button_1.vue";
import Button_2 from "./Button_2.vue";
import Button_3 from "./Button_3.vue";
import Button_text_1 from "./Button_text_1.vue";
import buttonOptions from "./Button-options.vue";
import ButtonTag from "./ButtonTag.vue";

export default [
  Button_1,
  Button_2,
  Button_3,
  Button_text_1,
  buttonOptions,
  ButtonTag
]
