import Input1 from "./Input-1.vue";
import InputPass from "./Input-pass.vue";

export default [
  Input1,
  InputPass
]