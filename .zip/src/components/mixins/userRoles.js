
export  default {
  data(){
    return  {
      userRoles : {
        user : "user",
        aidWorker : "aid_worker",
        organizationAdmin : "organization_administrator",
        platformAdmin: "platform_administrator"
      }
    }
  },
}