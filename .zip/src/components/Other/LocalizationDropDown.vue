<template>
	<div class="w-min">
		<button class="w-min h-full flex text-h3 items-center text-gray-c-500 font-semibold bg-gray-c-300 rounded-lg p-2">
			<img src="/src/assets/Flags/UA_flag.svg" class="w-6 h-4">
			<div class="ml-2 mr-3">Українська</div>
			<img src="/src/assets/dropdown-arrow.svg" class="w-3.5 h-2">
		</button>
	</div>

</template>

<script>
export default {
	name: "LocalizationDropDown",
	data (){
		return {
			lang : 'ua'
		}
	}
}
</script>

<style scoped>

</style>