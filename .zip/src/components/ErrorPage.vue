<template>
	<div>
		<h1>Error page</h1>
		<router-link tag="button">Welcome Screen</router-link>
	</div>
</template>

<script>
export default {

}
</script>

<style scoped>

</style>